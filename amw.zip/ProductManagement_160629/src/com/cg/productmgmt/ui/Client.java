package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductException;
import com.cg.productmgmt.service.ProductService;

public class Client {

	static Scanner sc=null;
	static IProductService productSer;
	public static void main(String[] args) throws ProductException {

		sc=new Scanner(System.in);
		productSer=new ProductService();
		int choice=0;
		while(true)
		{
			System.out.println("Select an option :");
			System.out.println("1.Update Product Price \t 2.get product details\t 3.Exit\n");

			choice=sc.nextInt();
			switch(choice)
			{
			case 1: updatePrice();
					break;
			case 2 :getProductDetails();
			        break;
			case 3: exit();
			default: System.exit(0);

			}

		}
	}
	private static void exit() {
	
		System.exit(0);
	}
	private static void updatePrice() {
		System.out.println("Enter the Product Category: ");
		String Category = sc.next();
		System.out.println("Enter hike Rate: ");
		int hike = sc.nextInt();
		try {
			if(productSer.validateHikeRate(hike))
			{
				int result=productSer.updateProducts(Category, hike);
				if(result==1){
				System.out.println(Category +" Updated Successfully"); }
				
			}
		}
		catch( Exception e)
		{
			e.printStackTrace();
		}
		

	}
	
	public static void getProductDetails()  {
		
		
		try {
			Map<String, Integer> pc;
			pc = productSer.getProductDetails();
			System.out.println(pc);
		} catch (ProductException e) {
			
			e.printStackTrace();
		}
		
	}
}
