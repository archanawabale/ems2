package com.cg.productmgmt.junit;

import org.junit.Assert;
import org.junit.Test;

import com.cg.productmgmt.service.ProductService;

public class ProductMgmtTest {

	ProductService service = new ProductService();
	@Test
	public void test1() {
		boolean result = service.validateHikeRate(-8);
		Assert.assertEquals(false, result);
	}
	
	@Test
	public void test2() {
		boolean result = service.validateHikeRate(6);
		Assert.assertEquals(true, result);
	}
	
	@Test
	public void test3() {
		boolean result = service.validateHikeRate(0);
		Assert.assertEquals(false, result);
	}
	
	
	
	

}
